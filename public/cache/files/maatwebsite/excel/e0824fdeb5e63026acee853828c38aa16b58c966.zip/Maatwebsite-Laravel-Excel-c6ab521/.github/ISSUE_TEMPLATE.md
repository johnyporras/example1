Please prefix your issue with one of the following: [BUG] [PROPOSAL] [QUESTION].

### Package version, Laravel version

### Expected behaviour

### Actual behaviour

#### Exception stack trace

#### Screenshot of Excel file

### Steps to reproduce the behaviour
