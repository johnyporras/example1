$mergeColumn = array(
     *                  'columns' => array('A','B','C','D'),
     *                  'rows' => array(
     *                      array(2,3),
     *                      array(5,11),
     *                      .....
     *                   )
     *            );