# Available border styles

| Style name  | PHPExcel class reference|
| ------------- |-----------------|
|none|PHPExcel_Style_Border::BORDER_NONE
|dashDot|PHPExcel_Style_Border::BORDER_DASHDOT
| dashDotDot|PHPExcel_Style_Border::BORDER_DASHDOTDOT
| dashed |PHPExcel_Style_Border::BORDER_DASHED
| dotted |PHPExcel_Style_Border::BORDER_DOTTED
| double |PHPExcel_Style_Border::BORDER_DOUBLE
| hair |PHPExcel_Style_Border::BORDER_HAIR
| medium |PHPExcel_Style_Border::BORDER_MEDIUM
| mediumDashDot |PHPExcel_Style_Border::BORDER_MEDIUMDASHDOT
| mediumDashDotDot |PHPExcel_Style_Border::BORDER_MEDIUMDASHDOTDOT
| mediumDashed |PHPExcel_Style_Border::BORDER_MEDIUMDASHED
| slantDashDot |PHPExcel_Style_Border::BORDER_SLANTDASHDOT
|  thick|PHPExcel_Style_Border::BORDER_THICK
|  thin|PHPExcel_Style_Border::BORDER_THIN