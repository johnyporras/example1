
@section('dataembed')
<dataembed id="{{ $id }}" remote="{{ $url }}"></dataembed>
@show

