<?php

namespace Zofe\Rapyd\DataForm\Field;


//TODO simple 
class Collection extends Container
{

    public $type = "collection";
    

}
