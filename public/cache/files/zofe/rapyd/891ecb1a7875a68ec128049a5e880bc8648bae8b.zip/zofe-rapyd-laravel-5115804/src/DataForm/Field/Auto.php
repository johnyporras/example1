<?php namespace Zofe\Rapyd\DataForm\Field;

class Auto extends Field
{
    public $type = "auto";

    public function build()
    {
        return "";
    }

}
