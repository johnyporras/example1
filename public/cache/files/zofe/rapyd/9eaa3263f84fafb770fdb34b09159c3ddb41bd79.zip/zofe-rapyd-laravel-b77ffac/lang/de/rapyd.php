<?php

return array(
    'save'    => 'speichern',
    'undo'    => 'zurück',
    'show'    => 'anzeigen',
    'modify'  => 'ändern',
    'delete'  => 'löschen',
    'add'     => 'hinzufügen',
    'reset'   => 'zurücksetzen',
    'search'  => 'suchen',
    'back'    => 'zurück',

    //dataedit
    'inserted'   => 'Neuen Eintrag erstellt.',
    'updated'    => 'Eintrag geändert.',
    'deleted'    => 'Eintrag gelöscht.',
    'err'        => 'Fehler beim lesen.',
    'err_unknown'=> 'Kein Eintrag ausgewählt.',
    'err_dup_pk' => 'Fehler. Primary key bereits vorhanden.',
    'conf_delete'=> 'Eintrag löschen?',
);
