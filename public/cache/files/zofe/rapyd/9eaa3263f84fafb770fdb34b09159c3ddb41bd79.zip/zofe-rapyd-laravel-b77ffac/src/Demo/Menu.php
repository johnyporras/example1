<?php namespace Zofe\Rapyd\Demo;

use Baum\Node;

class Menu extends Node {
   
    protected $guarded = [];

    protected $table = 'demo_menus';
}
