<?php

namespace Intervention\Image\Exception;

class NotFoundException extends \RuntimeException
{
    # nothing to override
}
