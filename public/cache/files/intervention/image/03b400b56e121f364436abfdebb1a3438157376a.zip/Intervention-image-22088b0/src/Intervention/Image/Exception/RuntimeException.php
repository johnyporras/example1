<?php

namespace Intervention\Image\Exception;

class RuntimeException extends \RuntimeException
{
    # nothing to override
}
