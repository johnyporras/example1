<?php

namespace Intervention\Image\Exception;

class NotReadableException extends \RuntimeException
{
    # nothing to override
}
